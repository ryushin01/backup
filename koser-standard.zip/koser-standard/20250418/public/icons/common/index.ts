import Spinner from "./spinner.svg";

export { Spinner };
