import CameraIcon from "./camera-icon50.svg";

export {
  CameraIcon,
};
