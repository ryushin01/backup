// 한페이지에 표시할 데이터 개수
export const PAGE_LIMIT_PC = 10;
export const PAGE_LIMIT_MOBILE = 5;
export const PAGE_LIMIT_ADMIN = 50;

//한번에 표시할 페이지 개수
export const PAGE_COUNT_PC = 10;
export const PAGE_COUNT_MOBILE = 5;
